## Synopsis

A Python-based Magic Eight Ball web application.

## Contributors

Michael Joseph Walsh <mjwalsh@mitre.org>, <nemonik@gmail.com>

## License

BSD 4-clause License
