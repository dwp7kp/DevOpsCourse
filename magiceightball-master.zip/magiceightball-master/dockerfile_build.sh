#!/bin/sh

docker build -t nemonik/magiceightball .
